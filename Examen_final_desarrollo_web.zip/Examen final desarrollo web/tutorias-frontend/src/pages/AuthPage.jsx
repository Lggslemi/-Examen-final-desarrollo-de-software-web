import React, { useState } from "react";

const API = "http://localhost:8080/api/v1";

export default function AuthPage({ onLogin }){
  const [mode, setMode] = useState("login");
  const [form, setForm] = useState({name:"", email:"", password:"", role:"student"});

  async function submit(e){
    e.preventDefault();
    try {
      if(mode === "login"){
        const res = await fetch(API + "/auth/login", {
          method:"POST",
          headers: {"Content-Type":"application/json"},
          body: JSON.stringify({email: form.email, password: form.password})
        });
        const j = await res.json();
        if(res.ok && j.token){
          // obtener perfil
          const profileRes = await fetch(API + "/users/me", { headers: { Authorization: "Bearer "+j.token }});
          const profile = profileRes.ok ? await profileRes.json() : null;
          localStorage.setItem("token", j.token);
          localStorage.setItem("user", JSON.stringify(profile));
          onLogin && onLogin(j.token, profile);
          alert("Login correcto");
        } else {
          alert("Error: " + JSON.stringify(j));
        }
      } else {
        // registrar
        const res = await fetch(API + "/users", {
          method:"POST",
          headers: {"Content-Type":"application/json"},
          body: JSON.stringify({name:form.name, email: form.email, password: form.password, role: form.role})
        });
        const j = await res.json();
        if(res.ok){
          alert("Usuario creado. Haz login.");
          setMode("login");
        } else {
          alert("Error: " + JSON.stringify(j));
        }
      }
    } catch(err){
      alert("Error de red: " + err.message);
    }
  }

  return (
    <div>
      <h3>{mode === "login" ? "Login" : "Registrar"}</h3>
      <form onSubmit={submit}>
        {mode === "register" && <>
          <label>Nombre</label>
          <input value={form.name} onChange={e=>setForm({...form, name:e.target.value})} />
        </>}
        <label>Email</label>
        <input value={form.email} onChange={e=>setForm({...form, email:e.target.value})} />
        <label>Password</label>
        <input type="password" value={form.password} onChange={e=>setForm({...form, password:e.target.value})} />

        {mode === "register" && <>
          <label>Role</label>
          <select value={form.role} onChange={e=>setForm({...form, role:e.target.value})}>
            <option value="student">Estudiante</option>
            <option value="teacher">Profesor</option>
          </select>
          <div style={{fontSize:12, color:"#666"}}>Escoja bien su rol.</div>
        </>}

        <div style={{marginTop:8}}>
          <button type="submit">{mode === "login" ? "Ingresar" : "Registrar"}</button>
          <button type="button" onClick={()=>setMode(mode==="login"?"register":"login")} style={{marginLeft:8}}>
            {mode==="login"?"Crear cuenta":"Ir a login"}
          </button>
        </div>
      </form>
    </div>
  );
}
