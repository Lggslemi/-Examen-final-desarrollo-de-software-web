import React, { useEffect, useState } from "react";

export default function TutoriasPage({ token, currentUser }){
  const [tutorias, setTutorias] = useState([]);
  const [expanded, setExpanded] = useState(null);
  const [editId, setEditId] = useState(null);
  const [form, setForm] = useState({});
  const [participantsMap, setParticipantsMap] = useState({});
  const [showCreate, setShowCreate] = useState(false);
  const [createForm, setCreateForm] = useState({
    fecha: new Date().toISOString().slice(0,10),
    fechaProgramada: new Date().toISOString().slice(0,10),
    horaInicio: "14:00:00",
    horaFin: "15:00:00",
    asignatura: "",
    tematica: "",
    lugar: ""
  });

  function authHeader(){
    return token ? { Authorization: "Bearer "+token } : {};
  }

  async function load(){
    try {
      const res = await fetch("http://localhost:8080/api/v1/tutorias", { headers: authHeader() });
      if(res.ok){
        setTutorias(await res.json());
      } else {
        setTutorias([]);
      }
    } catch(err){
      console.error("Error cargando tutorias:", err);
      setTutorias([]);
    }
  }

  useEffect(()=>{ load(); }, [token]);

  async function loadParticipants(tutoriaId){
    try {
      const res = await fetch(`http://localhost:8080/api/v1/participantes/tutoria/${tutoriaId}`, { headers: authHeader() });
      if(res.ok){
        const data = await res.json();
        setParticipantsMap(prev => ({...prev, [tutoriaId]: data}));
      } else {
        setParticipantsMap(prev => ({...prev, [tutoriaId]: []}));
      }
    } catch(err){
      console.error("Error cargando participantes:", err);
      setParticipantsMap(prev => ({...prev, [tutoriaId]: []}));
    }
  }

  function toggleExpand(id){
    setExpanded(expanded===id? null : id);
    if(expanded !== id) loadParticipants(id);
  }

  async function enroll(id){
    if(!token){ alert("Inicia sesión como estudiante"); return; }
    try {
      const res = await fetch(`http://localhost:8080/api/v1/tutorias/${id}/enroll`, {
        method: "POST", headers: {...authHeader(), "Content-Type":"application/json"}
      });
      const j = await res.json();
      if(res.ok){ alert("Inscrito"); loadParticipants(id); }
      else alert("Error: " + JSON.stringify(j));
    } catch(err){
      alert("Error de red al inscribirse: " + err.message);
    }
  }

  //
  async function addParticipant(id){
    if(!token){ alert("Debes iniciar sesión como profesor"); return; }
    const email = prompt("Email del estudiante a añadir:");
    if(!email) return;
    try {
      const resUsers = await fetch("http://localhost:8080/api/v1/users?role=student", { headers: authHeader() });
      if(!resUsers.ok){
        alert("No pude obtener la lista de estudiantes");
        return;
      }
      const users = await resUsers.json();
      const user = users.find(u => String(u.email).toLowerCase() === String(email).toLowerCase());
      if(!user){
        alert("No se encontró ningún estudiante con ese email.");
        return;
      }
      const res = await fetch(`http://localhost:8080/api/v1/tutorias/${id}/add-participant`, {
        method:"POST", headers: {...authHeader(), "Content-Type":"application/json"},
        body: JSON.stringify({ estudianteId: user.id })
      });
      const j = await res.json();
      if(res.ok){ alert("Estudiante añadido"); loadParticipants(id); }
      else alert("Error al añadir participante: " + JSON.stringify(j));
    } catch(err){
      alert("Error de red al añadir participante: " + err.message);
    }
  }

  async function removeParticipant(tutId, participantId){
    if(!confirm("Eliminar participante?")) return;
    try {
      const res = await fetch(`http://localhost:8080/api/v1/tutorias/${tutId}/participants/${participantId}`, {
        method:"DELETE", headers: authHeader()
      });
      if(res.ok){ alert("Eliminado"); loadParticipants(tutId); }
      else {
        const j = await res.json();
        alert("Error: " + JSON.stringify(j));
      }
    } catch(err){
      alert("Error de red al eliminar participante: " + err.message);
    }
  }

  // 
  function startEdit(t){
    // 
    setExpanded(t.id);
    setEditId(t.id);
    setForm({
      fecha: t.fecha || "",
      fechaProgramada: t.fechaProgramada || "",
      horaInicio: t.horaInicio || "",
      horaFin: t.horaFin || "",
      asignatura: t.asignatura || "",
      tematica: t.tematica || "",
      lugar: t.lugar || ""
    });
    //
    setTimeout(() => {
      const el = document.getElementById(`edit-${t.id}`);
      if(el && el.scrollIntoView) el.scrollIntoView({ behavior: "smooth", block: "center" });
    }, 80);
  }

  // try/catch- mensajes explícitos
  async function saveEdit(id){
    try {
      const res = await fetch(`http://localhost:8080/api/v1/tutorias/${id}`, {
        method:"PUT", headers: {...authHeader(), "Content-Type":"application/json"},
        body: JSON.stringify(form)
      });
      const j = await (res.headers.get("content-type") && res.headers.get("content-type").includes("application/json") ? res.json() : Promise.resolve({}));
      if(res.ok){
        alert("Tutoria actualizada correctamente");
        setEditId(null);
        await load();
        if(expanded === id) loadParticipants(id);
      } else {
        alert("Error actualizando: " + JSON.stringify(j));
      }
    } catch(err){
      alert("Error de red al guardar: " + err.message);
    }
  }

  async function deleteTutoria(id){
    if(!confirm("Eliminar tutoria?")) return;
    try {
      const res = await fetch(`http://localhost:8080/api/v1/tutorias/${id}`, {
        method:"DELETE", headers: authHeader()
      });
      if(res.ok){ alert("Eliminada"); load(); }
      else {
        const j = await res.json();
        alert("Error eliminando: " + JSON.stringify(j));
      }
    } catch(err){
      alert("Error de red al eliminar: " + err.message);
    }
  }

  // CREAR TUTORIA (solo profesor)
  async function crearTutoria(e){
    e.preventDefault();
    if(!token){ alert("Debes iniciar sesión como profesor"); return; }
    try {
      const res = await fetch("http://localhost:8080/api/v1/tutorias", {
        method:"POST",
        headers: {...authHeader(), "Content-Type":"application/json"},
        body: JSON.stringify(createForm)
      });
      const j = await res.json();
      if(res.ok){ alert("Tutoria creada"); setShowCreate(false); setCreateForm({
        fecha: new Date().toISOString().slice(0,10),
        fechaProgramada: new Date().toISOString().slice(0,10),
        horaInicio: "14:00:00",
        horaFin: "15:00:00",
        asignatura: "",
        tematica: "",
        lugar: ""
      }); load(); }
      else alert("Error creando: " + JSON.stringify(j));
    } catch(err){
      alert("Error de red al crear: " + err.message);
    }
  }

  return (
    <div>
      <h3>Tutorías</h3>

      {currentUser && currentUser.role === "teacher" && (
        <div style={{marginBottom:12}}>
          <button onClick={()=>setShowCreate(!showCreate)}>
            {showCreate ? "Cerrar formulario crear" : "Crear nueva tutoría"}
          </button>
        </div>
      )}

      {showCreate && currentUser && currentUser.role === "teacher" && (
        <form onSubmit={crearTutoria} style={{marginBottom:16, padding:10, border:"1px solid #eee", borderRadius:6, background:"#fafafa"}}>
          <div className="row">
            <div style={{flex:1}}>
              <label>Fecha</label>
              <input type="date" value={createForm.fecha} onChange={e=>setCreateForm({...createForm, fecha:e.target.value})} />
            </div>
            <div style={{flex:1}}>
              <label>Fecha Programada</label>
              <input type="date" value={createForm.fechaProgramada} onChange={e=>setCreateForm({...createForm, fechaProgramada:e.target.value})} />
            </div>
          </div>
          <label>Hora inicio</label>
          <input value={createForm.horaInicio} onChange={e=>setCreateForm({...createForm, horaInicio:e.target.value})} />
          <label>Hora fin</label>
          <input value={createForm.horaFin} onChange={e=>setCreateForm({...createForm, horaFin:e.target.value})} />
          <label>Asignatura</label>
          <input value={createForm.asignatura} onChange={e=>setCreateForm({...createForm, asignatura:e.target.value})} />
          <label>Temática</label>
          <textarea value={createForm.tematica} onChange={e=>setCreateForm({...createForm, tematica:e.target.value})} />
          <label>Lugar</label>
          <input value={createForm.lugar} onChange={e=>setCreateForm({...createForm, lugar:e.target.value})} />
          <div style={{marginTop:8}}>
            <button type="submit">Crear</button>
            <button type="button" onClick={()=>setShowCreate(false)} style={{marginLeft:8}}>Cancelar</button>
          </div>
        </form>
      )}

      <table className="table">
        <thead><tr><th>Fecha</th><th>Asignatura</th><th>Docente</th><th>Acciones</th></tr></thead>
        <tbody>
          {tutorias.map(t => (
            <React.Fragment key={t.id}>
            <tr>
              <td>{t.fecha}</td>
              <td>{t.asignatura}</td>
              <td>{t.docenteId}</td>
              <td>
                <button onClick={()=>toggleExpand(t.id)}>{expanded===t.id?"Cerrar":"Ver"}</button>
                {currentUser && currentUser.role === "student" && <button onClick={()=>enroll(t.id)} style={{marginLeft:6}}>Inscribirme</button>}
                {currentUser && currentUser.role === "teacher" && currentUser.id === t.docenteId && <>
                  <button onClick={()=>startEdit(t)} style={{marginLeft:6}}>Editar</button>
                  <button onClick={()=>addParticipant(t.id)} style={{marginLeft:6}}>Añadir participante</button>
                  <button onClick={()=>deleteTutoria(t.id)} style={{marginLeft:6}}>Borrar</button>
                </>}
              </td>
            </tr>

            {expanded === t.id && (
              <tr>
                <td colSpan="4">
                  <div style={{display:"flex", gap:20}}>
                    <div style={{flex:1}}>
                      <h4>Detalles</h4>
                      <div><strong>Temática:</strong> {t.tematica}</div>
                      <div><strong>Lugar:</strong> {t.lugar}</div>
                      <div><strong>Horario:</strong> {t.horaInicio} - {t.horaFin}</div>
                    </div>

                    <div style={{flex:1}}>
                      <h4>Participantes</h4>
                      <table className="table">
                        <thead><tr><th>Id</th><th>EstudianteId</th><th>Acción</th></tr></thead>
                        <tbody>
                          {(participantsMap[t.id] || []).map(p => (
                            <tr key={p.id}>
                              <td>{p.id}</td>
                              <td>{p.estudianteId}</td>
                              <td>
                                {(currentUser && (currentUser.id === p.estudianteId || (currentUser.role==="teacher" && currentUser.id===t.docenteId))) ?
                                  <button onClick={()=>removeParticipant(t.id, p.id)}>Eliminar</button>
                                  : <span style={{color:"#666"}}>-</span>
                                }
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>

                    {editId === t.id && (
                      <div id={`edit-${t.id}`} style={{flex:1}}>
                        <h4>Editar</h4>
                        <label>Asignatura</label>
                        <input value={form.asignatura||""} onChange={e=>setForm({...form, asignatura:e.target.value})} />
                        <label>Fecha</label>
                        <input type="date" value={form.fecha||""} onChange={e=>setForm({...form, fecha:e.target.value})} />
                        <label>Hora inicio</label>
                        <input value={form.horaInicio||""} onChange={e=>setForm({...form, horaInicio:e.target.value})} />
                        <label>Hora fin</label>
                        <input value={form.horaFin||""} onChange={e=>setForm({...form, horaFin:e.target.value})} />
                        <label>Temática</label>
                        <textarea value={form.tematica||""} onChange={e=>setForm({...form, tematica:e.target.value})} />
                        <div style={{marginTop:8}}>
                          <button onClick={()=>saveEdit(t.id)}>Guardar</button>
                          <button onClick={()=>setEditId(null)} style={{marginLeft:8}}>Cancelar</button>
                        </div>
                      </div>
                    )}
                  </div>
                </td>
              </tr>
            )}
            </React.Fragment>
          ))}
        </tbody>
      </table>
    </div>
  );
}
