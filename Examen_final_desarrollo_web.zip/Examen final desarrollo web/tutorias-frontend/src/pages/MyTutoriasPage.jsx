import React, { useEffect, useState } from "react";

export default function MyTutoriasPage({ token, currentUser }){
  const [tutorias, setTutorias] = useState([]);
  async function load(){
    if(!token) { setTutorias([]); return; }
    const res = await fetch("http://localhost:8080/api/v1/tutorias/mine", {
      headers: { Authorization: "Bearer "+token }
    });
    if(res.ok){
      setTutorias(await res.json());
    } else {
      setTutorias([]);
    }
  }
  useEffect(()=>{ load(); }, [token]);

  return (
    <div>
      <h3>Mis Tutorías</h3>
      {!token && <div>Inicia sesión para ver tus tutorías.</div>}
      <table className="table">
        <thead><tr><th>Fecha</th><th>Asignatura</th><th>Docente</th><th>Acciones</th></tr></thead>
        <tbody>
          {tutorias.map(t => (
            <tr key={t.id}>
              <td>{t.fecha}</td>
              <td>{t.asignatura}</td>
              <td>{t.docenteId}</td>
              <td>
                <span style={{color:"#666"}}>Ver en "Todas Tutorías" para acciones</span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
