import React, { useEffect, useState } from "react";

export default function UsersPage({ token }){
  const [users, setUsers] = useState([]);
  

  const roleMap = {
    teacher: "Profesor",
    student: "Estudiante",
  };
  

  const getRoleInSpanish = (role) => {
    
    return roleMap[role] || role; 
  }

  async function load(){
    const res = await fetch("http://localhost:8080/api/v1/users", { headers: token ? { Authorization: "Bearer "+token } : {} });
    if(res.ok){
      const j = await res.json();
      setUsers(j);
    } else {
      setUsers([]);
    }
  }
  useEffect(()=>{ load(); }, []);

  return (
    <div>
      <h3>Usuarios</h3>
      <table className="table">
        <thead><tr><th>Nombre</th><th>Email</th><th>Rol</th></tr></thead>
        <tbody>
          {users.map(u => (
            <tr key={u.id}>
              <td>{u.name}</td>
              <td>{u.email}</td>
              {}
              <td>
                {getRoleInSpanish(u.role)}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}