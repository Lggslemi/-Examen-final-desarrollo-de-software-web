import React, { useEffect, useState } from "react";
import UsersPage from "./pages/UsersPage";
import TutoriasPage from "./pages/TutoriasPage";
import AuthPage from "./pages/AuthPage";
import MyTutoriasPage from "./pages/MyTutoriasPage";

export default function App(){
  
 
  const roleMap = {
    teacher: "Profesor",
    student: "Estudiante",
  };
  

  const getRoleInSpanish = (role) => {
    return roleMap[role] || role;  
  }
  
  
  const defaultRoute = localStorage.getItem("token") ? "tutorias" : "auth";  
  const [route, setRoute] = useState(defaultRoute);
  
  const [token, setToken] = useState(localStorage.getItem("token"));
  const [currentUser, setCurrentUser] = useState(JSON.parse(localStorage.getItem("user") || "null"));

  useEffect(()=>{
    if(token && !currentUser){
      
      fetch("http://localhost:8080/api/v1/users/me", {
        headers: { Authorization: "Bearer " + token }
      }).then(r => {
        if(r.ok) return r.json();
        throw new Error("No autorizado");
      }).then(j => {
        setCurrentUser(j);
        localStorage.setItem("user", JSON.stringify(j));
        
        if (route === "auth") setRoute("tutorias");  
      }).catch(e => {
        console.log("Perfil no disponible", e);
        setToken(null);
        setCurrentUser(null);
        localStorage.removeItem("token");
        localStorage.removeItem("user");
        
        setRoute("auth");  
      });
    }
  }, [token, route, currentUser]); 

  function onLogin(token, user){
    setToken(token);
    setCurrentUser(user);
    localStorage.setItem("token", token);
    localStorage.setItem("user", JSON.stringify(user));
    
    setRoute("tutorias");  
  }
  
  function logout(){
    setToken(null);
    setCurrentUser(null);
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    
    setRoute("auth");  
  }

  return (
    <div className="container">
      <header>
        <h2>Tutorias</h2>
        <nav style={{marginBottom:8}}>
          {}
          {!token && <button onClick={() => setRoute("auth")}>Autenticar</button>}
          
          {}
          <button onClick={() => setRoute("users")}>Usuarios</button>
          <button onClick={() => setRoute("tutorias")}>Todas Tutorías</button>
          <button onClick={() => setRoute("mine")}>Mis Tutorías</button>
        </nav>
        <div style={{display:"flex", justifyContent:"space-between", alignItems:"center"}}>
          <div>
            {currentUser ? (
              <>
                <strong>{currentUser.name}</strong>  
                {}
                ({getRoleInSpanish(currentUser.role)})  
              </>
            ) : (
              <em>No autenticado</em>
            )}
          </div>
          <div>
            {}
            {token ? <button onClick={logout}>Cerrar Sección</button> : null}
          </div>
        </div>
      </header>
      
      {}
      {!token && <div style={{marginBottom:8,color:"#b00"}}>Debes iniciar sesión para ciertas operaciones</div>}

      {}
      {!token && <AuthPage onLogin={onLogin} />}  
      
      {}
      {token && route === "users" && <UsersPage token={token} />}
      {token && route === "tutorias" && <TutoriasPage token={token} currentUser={currentUser} />}
      {token && route === "mine" && <MyTutoriasPage token={token} currentUser={currentUser} />}

      {}
      {token && route === "auth" && <p>Sesión iniciada. Navega a otra sección.</p>}
    </div>
  );
}